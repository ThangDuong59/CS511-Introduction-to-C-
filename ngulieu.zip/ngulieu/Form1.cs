﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ngulieu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string txt_file_name; 
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_click(object sender, EventArgs e)
        {
            string text;
            if (comboBox1.Text == "abc")
            {
                text = "abc";
            }
            else
            {
                text = "Hello world";
            }
            richTextBox1.Text += "\n" + text;
            System.IO.File.WriteAllText(@"..\..\new_text_file.txt", richTextBox1.Text);
        }

        private void button2_click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName;

                fileName = dlg.FileName;
                txt_file_name = fileName;
                string Text = System.IO.File.ReadAllText(@fileName);
                richTextBox1.Text = Text;
            }
        }
    }
}
