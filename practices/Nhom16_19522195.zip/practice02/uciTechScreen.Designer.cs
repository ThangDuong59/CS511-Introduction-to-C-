﻿namespace practice02
{
    partial class uciTechScreen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uciTechScreen));
            this.panel_uciTechScreen_menuTopBar = new System.Windows.Forms.Panel();
            this.button_uniTechScreen_notification = new System.Windows.Forms.Button();
            this.panel_uciTechScreen_searchBar = new System.Windows.Forms.Panel();
            this.textBox_uciTechScreen_searchBar = new System.Windows.Forms.TextBox();
            this.pictureBox_uciTechScreen_magnifiyingGlass = new System.Windows.Forms.PictureBox();
            this.pictureBox_uciTechScreen_logo = new System.Windows.Forms.PictureBox();
            this.panel_uciTechScreen_mainContainer = new System.Windows.Forms.Panel();
            this.flowLayoutPanel_uciTechScreen_youMayLikeItems = new System.Windows.Forms.FlowLayoutPanel();
            this.labelText_uciTechScreen_youMayLike = new System.Windows.Forms.Label();
            this.labelText_uciTechScreen_category = new System.Windows.Forms.Label();
            this.panel_uciTechScreen_category = new System.Windows.Forms.Panel();
            this.button_uciTechScreen_speakerCategory = new System.Windows.Forms.Button();
            this.button_uciTechScreen_mouseCategory = new System.Windows.Forms.Button();
            this.button_uciTechScreen_keyBoardCategory = new System.Windows.Forms.Button();
            this.button_uciTechScreen_headPhoneCategory = new System.Windows.Forms.Button();
            this.button_uciTechScreen_tabletCateogry = new System.Windows.Forms.Button();
            this.button_uciTechScreen_laptopCategory = new System.Windows.Forms.Button();
            this.button_uciTechScreen_pcCategory = new System.Windows.Forms.Button();
            this.button_uciTechScreen_telephoneCategory = new System.Windows.Forms.Button();
            this.pictureBox_uciTech_panelScreen_advertisement = new System.Windows.Forms.PictureBox();
            this.panel_uciTechScreen_menuTopBar.SuspendLayout();
            this.panel_uciTechScreen_searchBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uciTechScreen_magnifiyingGlass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uciTechScreen_logo)).BeginInit();
            this.panel_uciTechScreen_mainContainer.SuspendLayout();
            this.panel_uciTechScreen_category.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uciTech_panelScreen_advertisement)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_uciTechScreen_menuTopBar
            // 
            this.panel_uciTechScreen_menuTopBar.BackColor = System.Drawing.Color.Thistle;
            this.panel_uciTechScreen_menuTopBar.Controls.Add(this.button_uniTechScreen_notification);
            this.panel_uciTechScreen_menuTopBar.Controls.Add(this.panel_uciTechScreen_searchBar);
            this.panel_uciTechScreen_menuTopBar.Controls.Add(this.pictureBox_uciTechScreen_logo);
            this.panel_uciTechScreen_menuTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_uciTechScreen_menuTopBar.Location = new System.Drawing.Point(0, 0);
            this.panel_uciTechScreen_menuTopBar.Name = "panel_uciTechScreen_menuTopBar";
            this.panel_uciTechScreen_menuTopBar.Size = new System.Drawing.Size(377, 49);
            this.panel_uciTechScreen_menuTopBar.TabIndex = 0;
            // 
            // button_uniTechScreen_notification
            // 
            this.button_uniTechScreen_notification.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_uniTechScreen_notification.BackgroundImage")));
            this.button_uniTechScreen_notification.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button_uniTechScreen_notification.FlatAppearance.BorderSize = 0;
            this.button_uniTechScreen_notification.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uniTechScreen_notification.Location = new System.Drawing.Point(337, 9);
            this.button_uniTechScreen_notification.Name = "button_uniTechScreen_notification";
            this.button_uniTechScreen_notification.Size = new System.Drawing.Size(32, 28);
            this.button_uniTechScreen_notification.TabIndex = 4;
            this.button_uniTechScreen_notification.UseVisualStyleBackColor = true;
            this.button_uniTechScreen_notification.Click += new System.EventHandler(this.button_click_uniTechScreen_notification);
            // 
            // panel_uciTechScreen_searchBar
            // 
            this.panel_uciTechScreen_searchBar.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_uciTechScreen_searchBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_uciTechScreen_searchBar.Controls.Add(this.textBox_uciTechScreen_searchBar);
            this.panel_uciTechScreen_searchBar.Controls.Add(this.pictureBox_uciTechScreen_magnifiyingGlass);
            this.panel_uciTechScreen_searchBar.Location = new System.Drawing.Point(55, 9);
            this.panel_uciTechScreen_searchBar.Name = "panel_uciTechScreen_searchBar";
            this.panel_uciTechScreen_searchBar.Size = new System.Drawing.Size(280, 29);
            this.panel_uciTechScreen_searchBar.TabIndex = 3;
            // 
            // textBox_uciTechScreen_searchBar
            // 
            this.textBox_uciTechScreen_searchBar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_uciTechScreen_searchBar.Location = new System.Drawing.Point(33, 2);
            this.textBox_uciTechScreen_searchBar.Name = "textBox_uciTechScreen_searchBar";
            this.textBox_uciTechScreen_searchBar.Size = new System.Drawing.Size(242, 23);
            this.textBox_uciTechScreen_searchBar.TabIndex = 1;
            this.textBox_uciTechScreen_searchBar.Text = "Nhập sản phẩm bạn cần tìm...";
            this.textBox_uciTechScreen_searchBar.Click += new System.EventHandler(this.textBox_click_uciTechScreen_searchBar);
            this.textBox_uciTechScreen_searchBar.TextChanged += new System.EventHandler(this.textBox_textChanged_uciTechScreen_searchBar);
            this.textBox_uciTechScreen_searchBar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_keyDown_uciTechScreen_searchBar);
            // 
            // pictureBox_uciTechScreen_magnifiyingGlass
            // 
            this.pictureBox_uciTechScreen_magnifiyingGlass.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox_uciTechScreen_magnifiyingGlass.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_uciTechScreen_magnifiyingGlass.Image")));
            this.pictureBox_uciTechScreen_magnifiyingGlass.Location = new System.Drawing.Point(4, 2);
            this.pictureBox_uciTechScreen_magnifiyingGlass.Name = "pictureBox_uciTechScreen_magnifiyingGlass";
            this.pictureBox_uciTechScreen_magnifiyingGlass.Size = new System.Drawing.Size(24, 22);
            this.pictureBox_uciTechScreen_magnifiyingGlass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_uciTechScreen_magnifiyingGlass.TabIndex = 4;
            this.pictureBox_uciTechScreen_magnifiyingGlass.TabStop = false;
            // 
            // pictureBox_uciTechScreen_logo
            // 
            this.pictureBox_uciTechScreen_logo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_uciTechScreen_logo.Image")));
            this.pictureBox_uciTechScreen_logo.Location = new System.Drawing.Point(3, 0);
            this.pictureBox_uciTechScreen_logo.Name = "pictureBox_uciTechScreen_logo";
            this.pictureBox_uciTechScreen_logo.Size = new System.Drawing.Size(51, 46);
            this.pictureBox_uciTechScreen_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox_uciTechScreen_logo.TabIndex = 0;
            this.pictureBox_uciTechScreen_logo.TabStop = false;
            // 
            // panel_uciTechScreen_mainContainer
            // 
            this.panel_uciTechScreen_mainContainer.AutoScroll = true;
            this.panel_uciTechScreen_mainContainer.BackColor = System.Drawing.Color.White;
            this.panel_uciTechScreen_mainContainer.Controls.Add(this.flowLayoutPanel_uciTechScreen_youMayLikeItems);
            this.panel_uciTechScreen_mainContainer.Controls.Add(this.labelText_uciTechScreen_youMayLike);
            this.panel_uciTechScreen_mainContainer.Controls.Add(this.labelText_uciTechScreen_category);
            this.panel_uciTechScreen_mainContainer.Controls.Add(this.panel_uciTechScreen_category);
            this.panel_uciTechScreen_mainContainer.Controls.Add(this.pictureBox_uciTech_panelScreen_advertisement);
            this.panel_uciTechScreen_mainContainer.Location = new System.Drawing.Point(0, 46);
            this.panel_uciTechScreen_mainContainer.Name = "panel_uciTechScreen_mainContainer";
            this.panel_uciTechScreen_mainContainer.Size = new System.Drawing.Size(394, 514);
            this.panel_uciTechScreen_mainContainer.TabIndex = 1;
            // 
            // flowLayoutPanel_uciTechScreen_youMayLikeItems
            // 
            this.flowLayoutPanel_uciTechScreen_youMayLikeItems.Location = new System.Drawing.Point(0, 372);
            this.flowLayoutPanel_uciTechScreen_youMayLikeItems.Name = "flowLayoutPanel_uciTechScreen_youMayLikeItems";
            this.flowLayoutPanel_uciTechScreen_youMayLikeItems.Size = new System.Drawing.Size(377, 231);
            this.flowLayoutPanel_uciTechScreen_youMayLikeItems.TabIndex = 4;
            // 
            // labelText_uciTechScreen_youMayLike
            // 
            this.labelText_uciTechScreen_youMayLike.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelText_uciTechScreen_youMayLike.Location = new System.Drawing.Point(3, 341);
            this.labelText_uciTechScreen_youMayLike.Name = "labelText_uciTechScreen_youMayLike";
            this.labelText_uciTechScreen_youMayLike.Size = new System.Drawing.Size(141, 28);
            this.labelText_uciTechScreen_youMayLike.TabIndex = 3;
            this.labelText_uciTechScreen_youMayLike.Text = "Có thể bạn thích";
            this.labelText_uciTechScreen_youMayLike.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelText_uciTechScreen_category
            // 
            this.labelText_uciTechScreen_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelText_uciTechScreen_category.Location = new System.Drawing.Point(3, 155);
            this.labelText_uciTechScreen_category.Name = "labelText_uciTechScreen_category";
            this.labelText_uciTechScreen_category.Size = new System.Drawing.Size(95, 28);
            this.labelText_uciTechScreen_category.TabIndex = 2;
            this.labelText_uciTechScreen_category.Text = "Danh mục";
            this.labelText_uciTechScreen_category.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_uciTechScreen_category
            // 
            this.panel_uciTechScreen_category.BackColor = System.Drawing.Color.White;
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_speakerCategory);
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_mouseCategory);
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_keyBoardCategory);
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_headPhoneCategory);
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_tabletCateogry);
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_laptopCategory);
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_pcCategory);
            this.panel_uciTechScreen_category.Controls.Add(this.button_uciTechScreen_telephoneCategory);
            this.panel_uciTechScreen_category.Location = new System.Drawing.Point(0, 186);
            this.panel_uciTechScreen_category.Name = "panel_uciTechScreen_category";
            this.panel_uciTechScreen_category.Size = new System.Drawing.Size(377, 152);
            this.panel_uciTechScreen_category.TabIndex = 1;
            // 
            // button_uciTechScreen_speakerCategory
            // 
            this.button_uciTechScreen_speakerCategory.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_speakerCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_speakerCategory.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_speakerCategory.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_speakerCategory.Image")));
            this.button_uciTechScreen_speakerCategory.Location = new System.Drawing.Point(290, 80);
            this.button_uciTechScreen_speakerCategory.Name = "button_uciTechScreen_speakerCategory";
            this.button_uciTechScreen_speakerCategory.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_speakerCategory.TabIndex = 7;
            this.button_uciTechScreen_speakerCategory.Text = "Loa";
            this.button_uciTechScreen_speakerCategory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_speakerCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_speakerCategory.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_speakerCategory.Click += new System.EventHandler(this.button_click_uciTechScreen_speakerCategory);
            // 
            // button_uciTechScreen_mouseCategory
            // 
            this.button_uciTechScreen_mouseCategory.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_mouseCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_mouseCategory.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_mouseCategory.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_mouseCategory.Image")));
            this.button_uciTechScreen_mouseCategory.Location = new System.Drawing.Point(193, 80);
            this.button_uciTechScreen_mouseCategory.Name = "button_uciTechScreen_mouseCategory";
            this.button_uciTechScreen_mouseCategory.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_uciTechScreen_mouseCategory.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_mouseCategory.TabIndex = 6;
            this.button_uciTechScreen_mouseCategory.Text = "Chuột";
            this.button_uciTechScreen_mouseCategory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_mouseCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_mouseCategory.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_mouseCategory.Click += new System.EventHandler(this.button_click_uciTechScreen_mouseCategory);
            // 
            // button_uciTechScreen_keyBoardCategory
            // 
            this.button_uciTechScreen_keyBoardCategory.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_keyBoardCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_keyBoardCategory.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_keyBoardCategory.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_keyBoardCategory.Image")));
            this.button_uciTechScreen_keyBoardCategory.Location = new System.Drawing.Point(102, 80);
            this.button_uciTechScreen_keyBoardCategory.Name = "button_uciTechScreen_keyBoardCategory";
            this.button_uciTechScreen_keyBoardCategory.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_keyBoardCategory.TabIndex = 5;
            this.button_uciTechScreen_keyBoardCategory.Text = "Bàn phím";
            this.button_uciTechScreen_keyBoardCategory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_keyBoardCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_keyBoardCategory.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_keyBoardCategory.Click += new System.EventHandler(this.button_click_uciTechScreen_keyBoardCategory);
            // 
            // button_uciTechScreen_headPhoneCategory
            // 
            this.button_uciTechScreen_headPhoneCategory.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_headPhoneCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_headPhoneCategory.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_headPhoneCategory.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_headPhoneCategory.Image")));
            this.button_uciTechScreen_headPhoneCategory.Location = new System.Drawing.Point(12, 80);
            this.button_uciTechScreen_headPhoneCategory.Name = "button_uciTechScreen_headPhoneCategory";
            this.button_uciTechScreen_headPhoneCategory.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_headPhoneCategory.TabIndex = 4;
            this.button_uciTechScreen_headPhoneCategory.Text = "Tai nghe";
            this.button_uciTechScreen_headPhoneCategory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_headPhoneCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_headPhoneCategory.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_headPhoneCategory.Click += new System.EventHandler(this.button_click_uciTechScreen_headPhoneCategory);
            // 
            // button_uciTechScreen_tabletCateogry
            // 
            this.button_uciTechScreen_tabletCateogry.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_tabletCateogry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_tabletCateogry.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_tabletCateogry.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_tabletCateogry.Image")));
            this.button_uciTechScreen_tabletCateogry.Location = new System.Drawing.Point(290, 9);
            this.button_uciTechScreen_tabletCateogry.Name = "button_uciTechScreen_tabletCateogry";
            this.button_uciTechScreen_tabletCateogry.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_tabletCateogry.TabIndex = 3;
            this.button_uciTechScreen_tabletCateogry.Text = "Tablet";
            this.button_uciTechScreen_tabletCateogry.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_tabletCateogry.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_tabletCateogry.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_tabletCateogry.Click += new System.EventHandler(this.button_click_uciTechScreen_tabletCateogry);
            // 
            // button_uciTechScreen_laptopCategory
            // 
            this.button_uciTechScreen_laptopCategory.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_laptopCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_laptopCategory.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_laptopCategory.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_laptopCategory.Image")));
            this.button_uciTechScreen_laptopCategory.Location = new System.Drawing.Point(193, 9);
            this.button_uciTechScreen_laptopCategory.Name = "button_uciTechScreen_laptopCategory";
            this.button_uciTechScreen_laptopCategory.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_laptopCategory.TabIndex = 2;
            this.button_uciTechScreen_laptopCategory.Text = "Laptop";
            this.button_uciTechScreen_laptopCategory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_laptopCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_laptopCategory.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_laptopCategory.Click += new System.EventHandler(this.button_click_uciTechScreen_laptopCategory);
            // 
            // button_uciTechScreen_pcCategory
            // 
            this.button_uciTechScreen_pcCategory.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_pcCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_pcCategory.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_pcCategory.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_pcCategory.Image")));
            this.button_uciTechScreen_pcCategory.Location = new System.Drawing.Point(102, 9);
            this.button_uciTechScreen_pcCategory.Name = "button_uciTechScreen_pcCategory";
            this.button_uciTechScreen_pcCategory.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_pcCategory.TabIndex = 1;
            this.button_uciTechScreen_pcCategory.Text = "PC";
            this.button_uciTechScreen_pcCategory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_pcCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_pcCategory.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_pcCategory.Click += new System.EventHandler(this.button_click_uciTechScreen_pcCategory);
            // 
            // button_uciTechScreen_telephoneCategory
            // 
            this.button_uciTechScreen_telephoneCategory.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_telephoneCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_telephoneCategory.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_telephoneCategory.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_telephoneCategory.Image")));
            this.button_uciTechScreen_telephoneCategory.Location = new System.Drawing.Point(12, 9);
            this.button_uciTechScreen_telephoneCategory.Name = "button_uciTechScreen_telephoneCategory";
            this.button_uciTechScreen_telephoneCategory.Size = new System.Drawing.Size(75, 65);
            this.button_uciTechScreen_telephoneCategory.TabIndex = 0;
            this.button_uciTechScreen_telephoneCategory.Text = "Điện thoại";
            this.button_uciTechScreen_telephoneCategory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_telephoneCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_uciTechScreen_telephoneCategory.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_telephoneCategory.Click += new System.EventHandler(this.button_click_uciTechScreen_telephoneCategory);
            // 
            // pictureBox_uciTech_panelScreen_advertisement
            // 
            this.pictureBox_uciTech_panelScreen_advertisement.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_uciTech_panelScreen_advertisement.Image")));
            this.pictureBox_uciTech_panelScreen_advertisement.InitialImage = null;
            this.pictureBox_uciTech_panelScreen_advertisement.Location = new System.Drawing.Point(0, 0);
            this.pictureBox_uciTech_panelScreen_advertisement.Name = "pictureBox_uciTech_panelScreen_advertisement";
            this.pictureBox_uciTech_panelScreen_advertisement.Size = new System.Drawing.Size(377, 152);
            this.pictureBox_uciTech_panelScreen_advertisement.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_uciTech_panelScreen_advertisement.TabIndex = 0;
            this.pictureBox_uciTech_panelScreen_advertisement.TabStop = false;
            // 
            // uciTechScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel_uciTechScreen_mainContainer);
            this.Controls.Add(this.panel_uciTechScreen_menuTopBar);
            this.Name = "uciTechScreen";
            this.Size = new System.Drawing.Size(377, 560);
            this.panel_uciTechScreen_menuTopBar.ResumeLayout(false);
            this.panel_uciTechScreen_searchBar.ResumeLayout(false);
            this.panel_uciTechScreen_searchBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uciTechScreen_magnifiyingGlass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uciTechScreen_logo)).EndInit();
            this.panel_uciTechScreen_mainContainer.ResumeLayout(false);
            this.panel_uciTechScreen_category.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_uciTech_panelScreen_advertisement)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_uciTechScreen_menuTopBar;
        private System.Windows.Forms.PictureBox pictureBox_uciTechScreen_logo;
        private System.Windows.Forms.Panel panel_uciTechScreen_mainContainer;
        private System.Windows.Forms.TextBox textBox_uciTechScreen_searchBar;
        private System.Windows.Forms.PictureBox pictureBox_uciTech_panelScreen_advertisement;
        private System.Windows.Forms.Panel panel_uciTechScreen_category;
        private System.Windows.Forms.Button button_uciTechScreen_speakerCategory;
        private System.Windows.Forms.Button button_uciTechScreen_mouseCategory;
        private System.Windows.Forms.Button button_uciTechScreen_keyBoardCategory;
        private System.Windows.Forms.Button button_uciTechScreen_headPhoneCategory;
        private System.Windows.Forms.Button button_uciTechScreen_tabletCateogry;
        private System.Windows.Forms.Button button_uciTechScreen_laptopCategory;
        private System.Windows.Forms.Button button_uciTechScreen_pcCategory;
        private System.Windows.Forms.Button button_uciTechScreen_telephoneCategory;
        private System.Windows.Forms.Label labelText_uciTechScreen_category;
        private System.Windows.Forms.Panel panel_uciTechScreen_searchBar;
        private System.Windows.Forms.PictureBox pictureBox_uciTechScreen_magnifiyingGlass;
        private System.Windows.Forms.Button button_uniTechScreen_notification;
        private System.Windows.Forms.Label labelText_uciTechScreen_youMayLike;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_uciTechScreen_youMayLikeItems;
    }
}
