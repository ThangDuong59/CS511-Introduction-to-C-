﻿namespace practice02
{
    partial class ucHistoryScreen
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_ucHistoryScreen_title = new System.Windows.Forms.Panel();
            this.labelText_ucHistoryScreen_title = new System.Windows.Forms.Label();
            this.panel_ucHistoryScreen_title.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_ucHistoryScreen_title
            // 
            this.panel_ucHistoryScreen_title.BackColor = System.Drawing.Color.Thistle;
            this.panel_ucHistoryScreen_title.Controls.Add(this.labelText_ucHistoryScreen_title);
            this.panel_ucHistoryScreen_title.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_ucHistoryScreen_title.Location = new System.Drawing.Point(0, 0);
            this.panel_ucHistoryScreen_title.Name = "panel_ucHistoryScreen_title";
            this.panel_ucHistoryScreen_title.Size = new System.Drawing.Size(377, 45);
            this.panel_ucHistoryScreen_title.TabIndex = 5;
            // 
            // labelText_ucHistoryScreen_title
            // 
            this.labelText_ucHistoryScreen_title.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelText_ucHistoryScreen_title.ForeColor = System.Drawing.Color.Black;
            this.labelText_ucHistoryScreen_title.Location = new System.Drawing.Point(95, 10);
            this.labelText_ucHistoryScreen_title.Name = "labelText_ucHistoryScreen_title";
            this.labelText_ucHistoryScreen_title.Size = new System.Drawing.Size(186, 23);
            this.labelText_ucHistoryScreen_title.TabIndex = 0;
            this.labelText_ucHistoryScreen_title.Text = "Lịch sử giao dịch";
            this.labelText_ucHistoryScreen_title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ucHistoryScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel_ucHistoryScreen_title);
            this.Name = "ucHistoryScreen";
            this.Size = new System.Drawing.Size(377, 563);
            this.panel_ucHistoryScreen_title.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_ucHistoryScreen_title;
        private System.Windows.Forms.Label labelText_ucHistoryScreen_title;
    }
}
