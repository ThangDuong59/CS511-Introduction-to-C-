﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practice02
{
    public partial class ucMyOrderScreen : UserControl
    {
        #region Properties
        private bool _isCheckedAll;
        private bool _isChecBoxEnabled;
        private string _totalPrice = "0";

        [Category("Custom Props")]
        public bool CheckBoxCheckedAll
        {
            get { return _isCheckedAll; }
            set { _isCheckedAll = value; checkBox_ucMyOrderScreen_checkAll.Checked = value; }
        }

        [Category("Custom Props")]
        public bool CheckBoxEnabled
        {
            get { return _isChecBoxEnabled; }
            set { _isChecBoxEnabled = value; checkBox_ucMyOrderScreen_checkAll.Enabled = value; }
        }

        [Category("Custom Props")]
        public string totalPrice
        {
            get { return _totalPrice; }
            set { _totalPrice = value; labelValue_ucMyOrderScreen_totalPrice.Text = value + "đ"; }
        }

        #endregion
        public ucMyOrderScreen()
        {
            InitializeComponent();
        }

        private void checkBox_checkedChanged_ucMyOrderScreen_checkAll(object sender, EventArgs e)
        {

        }

        private void button_click_ucMyOrderScreen_paying(object sender, EventArgs e)
        {
            DataTable dt = formMain.Instance.UserOrderedHistoryDataTable;
            foreach(ucOrderedItemUI ucOrderedItemInstance in flowLayoutPanel_ucMyOrderScreen.Controls)
            {
                if (ucOrderedItemInstance.CheckBoxIsBuy == true)
                { 
                    int total_price = ucOrderedItemInstance.Quantity * Convert.ToInt32(ucOrderedItemInstance.Price.Replace(".", "").Replace("đ", ""));
                    int num_bought = dt.Rows.Count + 1;

                    string OrderID = "DH" + num_bought.ToString();
                    string OrderDate = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.Local, TimeZoneInfo.FindSystemTimeZoneById("SE Asia Standard Time")).ToString("dd/MM/yyyy");
                    string ProductID = ucOrderedItemInstance.ProductID;
                    string ProductName = ucOrderedItemInstance.ProductName;
                    string ProductBrand = ucOrderedItemInstance.Brand;
                    string ProductPrice = ucOrderedItemInstance.Price;
                    string DiscountCode = ucOrderedItemInstance.DiscountCode;
                    string ExchangeMethod = ucOrderedItemInstance.ExchangeMethod.ToString();
                    string ProductQuantity = ucOrderedItemInstance.Quantity.ToString();
                    string TotalPrice = total_price.ToString();
                    string OrderStatus = "0";

                    dt.Rows.Add(OrderID, OrderDate, ProductID, ProductName, ProductBrand, ProductPrice, DiscountCode, ExchangeMethod, ProductQuantity, TotalPrice, OrderStatus);

                    flowLayoutPanel_ucMyOrderScreen.Controls.Remove(ucOrderedItemInstance); 
                    checkBox_ucMyOrderScreen_checkAll.Checked = false;
                    checkBox_ucMyOrderScreen_checkAll.Enabled = false;
                }
            }
            _totalPrice = "0";
            labelValue_ucMyOrderScreen_totalPrice.Text = "0đ";
        }

        private void pictureBox_click_ucMyOrderScreen_trash(object sender, EventArgs e)
        {
            if (flowLayoutPanel_ucMyOrderScreen.Controls.Count > 0)
            {
                flowLayoutPanel_ucMyOrderScreen.Controls.Clear();
                ucMyOrderScreen ucMyOrderScreenInstance = formMain.Instance.PanelContainer.Controls["ucMyOrderScreen"] as ucMyOrderScreen;
                ucMyOrderScreenInstance.totalPrice = "0";
            }
        }
    }
}
