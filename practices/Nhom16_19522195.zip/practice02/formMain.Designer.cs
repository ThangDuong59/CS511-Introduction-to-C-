﻿namespace practice02
{
    partial class formMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formMain));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_uciTechScreen_toPersonalScreen = new System.Windows.Forms.Button();
            this.button_uciTechScreen_toHistoryScreen = new System.Windows.Forms.Button();
            this.button_uciTechScreen_toShoppingScreen = new System.Windows.Forms.Button();
            this.button_uciTechScreen_toiTechHome = new System.Windows.Forms.Button();
            this.panelContainer_formMain = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Thistle;
            this.panel1.Controls.Add(this.button_uciTechScreen_toPersonalScreen);
            this.panel1.Controls.Add(this.button_uciTechScreen_toHistoryScreen);
            this.panel1.Controls.Add(this.button_uciTechScreen_toShoppingScreen);
            this.panel1.Controls.Add(this.button_uciTechScreen_toiTechHome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 563);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(377, 64);
            this.panel1.TabIndex = 0;
            // 
            // button_uciTechScreen_toPersonalScreen
            // 
            this.button_uciTechScreen_toPersonalScreen.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_toPersonalScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_toPersonalScreen.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_toPersonalScreen.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_toPersonalScreen.Image")));
            this.button_uciTechScreen_toPersonalScreen.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_uciTechScreen_toPersonalScreen.Location = new System.Drawing.Point(285, 2);
            this.button_uciTechScreen_toPersonalScreen.Name = "button_uciTechScreen_toPersonalScreen";
            this.button_uciTechScreen_toPersonalScreen.Size = new System.Drawing.Size(89, 59);
            this.button_uciTechScreen_toPersonalScreen.TabIndex = 7;
            this.button_uciTechScreen_toPersonalScreen.Text = "Cá nhân";
            this.button_uciTechScreen_toPersonalScreen.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_toPersonalScreen.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_toPersonalScreen.Click += new System.EventHandler(this.button_click_uciTechScreen_toPersonalScreen);
            // 
            // button_uciTechScreen_toHistoryScreen
            // 
            this.button_uciTechScreen_toHistoryScreen.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_toHistoryScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_toHistoryScreen.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_toHistoryScreen.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_toHistoryScreen.Image")));
            this.button_uciTechScreen_toHistoryScreen.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_uciTechScreen_toHistoryScreen.Location = new System.Drawing.Point(190, 2);
            this.button_uciTechScreen_toHistoryScreen.Name = "button_uciTechScreen_toHistoryScreen";
            this.button_uciTechScreen_toHistoryScreen.Size = new System.Drawing.Size(89, 59);
            this.button_uciTechScreen_toHistoryScreen.TabIndex = 6;
            this.button_uciTechScreen_toHistoryScreen.Text = "Lịch sử GD";
            this.button_uciTechScreen_toHistoryScreen.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_toHistoryScreen.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_toHistoryScreen.Click += new System.EventHandler(this.button_click_uciTechScreen_toHistoryScreen);
            // 
            // button_uciTechScreen_toShoppingScreen
            // 
            this.button_uciTechScreen_toShoppingScreen.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_toShoppingScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_toShoppingScreen.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_toShoppingScreen.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_toShoppingScreen.Image")));
            this.button_uciTechScreen_toShoppingScreen.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_uciTechScreen_toShoppingScreen.Location = new System.Drawing.Point(89, 2);
            this.button_uciTechScreen_toShoppingScreen.Name = "button_uciTechScreen_toShoppingScreen";
            this.button_uciTechScreen_toShoppingScreen.Size = new System.Drawing.Size(89, 59);
            this.button_uciTechScreen_toShoppingScreen.TabIndex = 5;
            this.button_uciTechScreen_toShoppingScreen.Text = "Thanh toán";
            this.button_uciTechScreen_toShoppingScreen.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_toShoppingScreen.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_toShoppingScreen.Click += new System.EventHandler(this.button_click_uciTechScreen_toShoppingScreen);
            // 
            // button_uciTechScreen_toiTechHome
            // 
            this.button_uciTechScreen_toiTechHome.FlatAppearance.BorderSize = 0;
            this.button_uciTechScreen_toiTechHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_uciTechScreen_toiTechHome.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_uciTechScreen_toiTechHome.Image = ((System.Drawing.Image)(resources.GetObject("button_uciTechScreen_toiTechHome.Image")));
            this.button_uciTechScreen_toiTechHome.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_uciTechScreen_toiTechHome.Location = new System.Drawing.Point(3, 2);
            this.button_uciTechScreen_toiTechHome.Name = "button_uciTechScreen_toiTechHome";
            this.button_uciTechScreen_toiTechHome.Size = new System.Drawing.Size(80, 59);
            this.button_uciTechScreen_toiTechHome.TabIndex = 4;
            this.button_uciTechScreen_toiTechHome.Text = "iTech";
            this.button_uciTechScreen_toiTechHome.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_uciTechScreen_toiTechHome.UseVisualStyleBackColor = true;
            this.button_uciTechScreen_toiTechHome.Click += new System.EventHandler(this.button_click_uciTechScreen_toiTechHome);
            // 
            // panelContainer_formMain
            // 
            this.panelContainer_formMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContainer_formMain.Location = new System.Drawing.Point(0, 0);
            this.panelContainer_formMain.Name = "panelContainer_formMain";
            this.panelContainer_formMain.Size = new System.Drawing.Size(377, 563);
            this.panelContainer_formMain.TabIndex = 1;
            // 
            // formMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 627);
            this.Controls.Add(this.panelContainer_formMain);
            this.Controls.Add(this.panel1);
            this.Name = "formMain";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_uciTechScreen_toPersonalScreen;
        private System.Windows.Forms.Button button_uciTechScreen_toHistoryScreen;
        private System.Windows.Forms.Button button_uciTechScreen_toShoppingScreen;
        private System.Windows.Forms.Button button_uciTechScreen_toiTechHome;
        private System.Windows.Forms.Panel panelContainer_formMain;
    }
}

