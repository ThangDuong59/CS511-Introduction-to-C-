﻿namespace exercise6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.pictureBox_Example = new System.Windows.Forms.PictureBox();
            this.richTextBox_block1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block6 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block8 = new System.Windows.Forms.RichTextBox();
            this.richTextBox_block9 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label_steps = new System.Windows.Forms.Label();
            this.button_start = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Example)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_Example
            // 
            this.pictureBox_Example.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Example.Image")));
            this.pictureBox_Example.Location = new System.Drawing.Point(459, 55);
            this.pictureBox_Example.Name = "pictureBox_Example";
            this.pictureBox_Example.Size = new System.Drawing.Size(336, 300);
            this.pictureBox_Example.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Example.TabIndex = 0;
            this.pictureBox_Example.TabStop = false;
            // 
            // richTextBox_block1
            // 
            this.richTextBox_block1.BackColor = System.Drawing.Color.White;
            this.richTextBox_block1.Location = new System.Drawing.Point(12, 55);
            this.richTextBox_block1.Name = "richTextBox_block1";
            this.richTextBox_block1.ReadOnly = true;
            this.richTextBox_block1.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block1.TabIndex = 1;
            this.richTextBox_block1.Text = "";
            this.richTextBox_block1.TextChanged += new System.EventHandler(this.richTextBox_block1_TextChanged);
            // 
            // richTextBox_block2
            // 
            this.richTextBox_block2.BackColor = System.Drawing.Color.Blue;
            this.richTextBox_block2.Location = new System.Drawing.Point(126, 55);
            this.richTextBox_block2.Name = "richTextBox_block2";
            this.richTextBox_block2.ReadOnly = true;
            this.richTextBox_block2.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block2.TabIndex = 2;
            this.richTextBox_block2.Text = "";
            // 
            // richTextBox_block3
            // 
            this.richTextBox_block3.BackColor = System.Drawing.Color.Green;
            this.richTextBox_block3.Location = new System.Drawing.Point(240, 55);
            this.richTextBox_block3.Name = "richTextBox_block3";
            this.richTextBox_block3.ReadOnly = true;
            this.richTextBox_block3.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block3.TabIndex = 3;
            this.richTextBox_block3.Text = "";
            // 
            // richTextBox_block4
            // 
            this.richTextBox_block4.BackColor = System.Drawing.Color.Red;
            this.richTextBox_block4.Location = new System.Drawing.Point(12, 157);
            this.richTextBox_block4.Name = "richTextBox_block4";
            this.richTextBox_block4.ReadOnly = true;
            this.richTextBox_block4.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block4.TabIndex = 4;
            this.richTextBox_block4.Text = "";
            // 
            // richTextBox_block5
            // 
            this.richTextBox_block5.BackColor = System.Drawing.Color.Green;
            this.richTextBox_block5.Location = new System.Drawing.Point(126, 157);
            this.richTextBox_block5.Name = "richTextBox_block5";
            this.richTextBox_block5.ReadOnly = true;
            this.richTextBox_block5.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block5.TabIndex = 5;
            this.richTextBox_block5.Text = "";
            // 
            // richTextBox_block6
            // 
            this.richTextBox_block6.BackColor = System.Drawing.Color.Blue;
            this.richTextBox_block6.Location = new System.Drawing.Point(240, 157);
            this.richTextBox_block6.Name = "richTextBox_block6";
            this.richTextBox_block6.ReadOnly = true;
            this.richTextBox_block6.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block6.TabIndex = 6;
            this.richTextBox_block6.Text = "";
            // 
            // richTextBox_block7
            // 
            this.richTextBox_block7.BackColor = System.Drawing.Color.Green;
            this.richTextBox_block7.Location = new System.Drawing.Point(12, 259);
            this.richTextBox_block7.Name = "richTextBox_block7";
            this.richTextBox_block7.ReadOnly = true;
            this.richTextBox_block7.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block7.TabIndex = 7;
            this.richTextBox_block7.Text = "";
            // 
            // richTextBox_block8
            // 
            this.richTextBox_block8.BackColor = System.Drawing.Color.Blue;
            this.richTextBox_block8.Location = new System.Drawing.Point(126, 259);
            this.richTextBox_block8.Name = "richTextBox_block8";
            this.richTextBox_block8.ReadOnly = true;
            this.richTextBox_block8.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block8.TabIndex = 8;
            this.richTextBox_block8.Text = "";
            // 
            // richTextBox_block9
            // 
            this.richTextBox_block9.BackColor = System.Drawing.Color.Red;
            this.richTextBox_block9.Location = new System.Drawing.Point(240, 259);
            this.richTextBox_block9.Name = "richTextBox_block9";
            this.richTextBox_block9.ReadOnly = true;
            this.richTextBox_block9.Size = new System.Drawing.Size(108, 96);
            this.richTextBox_block9.TabIndex = 9;
            this.richTextBox_block9.Text = "";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(454, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "Example";
            // 
            // label_steps
            // 
            this.label_steps.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_steps.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label_steps.Location = new System.Drawing.Point(12, 413);
            this.label_steps.Name = "label_steps";
            this.label_steps.Size = new System.Drawing.Size(163, 23);
            this.label_steps.TabIndex = 11;
            this.label_steps.Text = "Steps: 0";
            // 
            // button_start
            // 
            this.button_start.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button_start.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_start.ForeColor = System.Drawing.SystemColors.Control;
            this.button_start.Image = ((System.Drawing.Image)(resources.GetObject("button_start.Image")));
            this.button_start.Location = new System.Drawing.Point(333, 371);
            this.button_start.Name = "button_start";
            this.button_start.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_start.Size = new System.Drawing.Size(142, 82);
            this.button_start.TabIndex = 12;
            this.button_start.Text = "Start";
            this.button_start.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_start.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_start.UseVisualStyleBackColor = false;
            this.button_start.Click += new System.EventHandler(this.button_start_click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Cyan;
            this.label2.Location = new System.Drawing.Point(397, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 355);
            this.label2.TabIndex = 13;
            this.label2.Text = "|||||||||||||||||||||||\r\n";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(811, 462);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.label_steps);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox_block9);
            this.Controls.Add(this.richTextBox_block8);
            this.Controls.Add(this.richTextBox_block7);
            this.Controls.Add(this.richTextBox_block6);
            this.Controls.Add(this.richTextBox_block5);
            this.Controls.Add(this.richTextBox_block4);
            this.Controls.Add(this.richTextBox_block3);
            this.Controls.Add(this.richTextBox_block2);
            this.Controls.Add(this.richTextBox_block1);
            this.Controls.Add(this.pictureBox_Example);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(827, 501);
            this.MinimumSize = new System.Drawing.Size(827, 501);
            this.Name = "Form2";
            this.Text = "Game";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.form_keyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.form_keyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Example)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_Example;
        private System.Windows.Forms.RichTextBox richTextBox_block1;
        private System.Windows.Forms.RichTextBox richTextBox_block2;
        private System.Windows.Forms.RichTextBox richTextBox_block3;
        private System.Windows.Forms.RichTextBox richTextBox_block4;
        private System.Windows.Forms.RichTextBox richTextBox_block5;
        private System.Windows.Forms.RichTextBox richTextBox_block6;
        private System.Windows.Forms.RichTextBox richTextBox_block7;
        private System.Windows.Forms.RichTextBox richTextBox_block8;
        private System.Windows.Forms.RichTextBox richTextBox_block9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_steps;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Label label2;
    }
}