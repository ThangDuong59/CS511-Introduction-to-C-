﻿namespace BangGiaCuoc
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.giup_viec_nha_groupbox = new System.Windows.Forms.GroupBox();
            this.dich_vu_khac_button = new System.Windows.Forms.Button();
            this.tong_ve_sinh_button = new System.Windows.Forms.Button();
            this.ve_sinh_may_lanh_button = new System.Windows.Forms.Button();
            this.nau_an_button = new System.Windows.Forms.Button();
            this.don_dep_nha_button = new System.Windows.Forms.Button();
            this.giat_ui_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.home_picturebox = new System.Windows.Forms.PictureBox();
            this.cart_picturebox = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.giat_ui_text_box = new System.Windows.Forms.TextBox();
            this.nau_an_text_box = new System.Windows.Forms.TextBox();
            this.don_dep_text_box = new System.Windows.Forms.TextBox();
            this.tong_ve_sinh_text_box = new System.Windows.Forms.TextBox();
            this.ve_sinh_may_lanh_text_box = new System.Windows.Forms.TextBox();
            this.thong_tin_gio_hang_groupbox = new System.Windows.Forms.GroupBox();
            this.dich_vu_khac_text_box = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.thanh_toan_text_box = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.giup_viec_nha_groupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.home_picturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cart_picturebox)).BeginInit();
            this.thong_tin_gio_hang_groupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // giup_viec_nha_groupbox
            // 
            this.giup_viec_nha_groupbox.BackColor = System.Drawing.Color.LightSalmon;
            this.giup_viec_nha_groupbox.Controls.Add(this.dich_vu_khac_button);
            this.giup_viec_nha_groupbox.Controls.Add(this.tong_ve_sinh_button);
            this.giup_viec_nha_groupbox.Controls.Add(this.ve_sinh_may_lanh_button);
            this.giup_viec_nha_groupbox.Controls.Add(this.nau_an_button);
            this.giup_viec_nha_groupbox.Controls.Add(this.don_dep_nha_button);
            this.giup_viec_nha_groupbox.Controls.Add(this.giat_ui_button);
            this.giup_viec_nha_groupbox.Controls.Add(this.label1);
            this.giup_viec_nha_groupbox.Location = new System.Drawing.Point(381, 0);
            this.giup_viec_nha_groupbox.Name = "giup_viec_nha_groupbox";
            this.giup_viec_nha_groupbox.Size = new System.Drawing.Size(375, 495);
            this.giup_viec_nha_groupbox.TabIndex = 0;
            this.giup_viec_nha_groupbox.TabStop = false;
            // 
            // dich_vu_khac_button
            // 
            this.dich_vu_khac_button.BackColor = System.Drawing.Color.Aqua;
            this.dich_vu_khac_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("dich_vu_khac_button.BackgroundImage")));
            this.dich_vu_khac_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.dich_vu_khac_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dich_vu_khac_button.ForeColor = System.Drawing.Color.DarkRed;
            this.dich_vu_khac_button.Location = new System.Drawing.Point(220, 356);
            this.dich_vu_khac_button.Name = "dich_vu_khac_button";
            this.dich_vu_khac_button.Size = new System.Drawing.Size(113, 96);
            this.dich_vu_khac_button.TabIndex = 6;
            this.dich_vu_khac_button.Text = "Dịch vụ khác";
            this.dich_vu_khac_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.dich_vu_khac_button.UseVisualStyleBackColor = false;
            this.dich_vu_khac_button.UseWaitCursor = true;
            this.dich_vu_khac_button.Click += new System.EventHandler(this.dich_vu_khac_click_box);
            // 
            // tong_ve_sinh_button
            // 
            this.tong_ve_sinh_button.BackColor = System.Drawing.Color.Aqua;
            this.tong_ve_sinh_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tong_ve_sinh_button.BackgroundImage")));
            this.tong_ve_sinh_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tong_ve_sinh_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tong_ve_sinh_button.ForeColor = System.Drawing.Color.DarkRed;
            this.tong_ve_sinh_button.Location = new System.Drawing.Point(220, 221);
            this.tong_ve_sinh_button.Name = "tong_ve_sinh_button";
            this.tong_ve_sinh_button.Size = new System.Drawing.Size(113, 96);
            this.tong_ve_sinh_button.TabIndex = 5;
            this.tong_ve_sinh_button.Text = "Tổng vệ sinh";
            this.tong_ve_sinh_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tong_ve_sinh_button.UseVisualStyleBackColor = false;
            this.tong_ve_sinh_button.Click += new System.EventHandler(this.tong_ve_sinh_click_box);
            // 
            // ve_sinh_may_lanh_button
            // 
            this.ve_sinh_may_lanh_button.BackColor = System.Drawing.Color.Aqua;
            this.ve_sinh_may_lanh_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ve_sinh_may_lanh_button.BackgroundImage")));
            this.ve_sinh_may_lanh_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ve_sinh_may_lanh_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ve_sinh_may_lanh_button.ForeColor = System.Drawing.Color.DarkRed;
            this.ve_sinh_may_lanh_button.Location = new System.Drawing.Point(220, 85);
            this.ve_sinh_may_lanh_button.Name = "ve_sinh_may_lanh_button";
            this.ve_sinh_may_lanh_button.Size = new System.Drawing.Size(113, 96);
            this.ve_sinh_may_lanh_button.TabIndex = 4;
            this.ve_sinh_may_lanh_button.Text = "Vệ sinh máy lạnh";
            this.ve_sinh_may_lanh_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ve_sinh_may_lanh_button.UseVisualStyleBackColor = false;
            this.ve_sinh_may_lanh_button.Click += new System.EventHandler(this.ve_sinh_may_lanh_click_box);
            // 
            // nau_an_button
            // 
            this.nau_an_button.BackColor = System.Drawing.Color.Aqua;
            this.nau_an_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("nau_an_button.BackgroundImage")));
            this.nau_an_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.nau_an_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nau_an_button.ForeColor = System.Drawing.Color.DarkRed;
            this.nau_an_button.Location = new System.Drawing.Point(42, 356);
            this.nau_an_button.Name = "nau_an_button";
            this.nau_an_button.Size = new System.Drawing.Size(113, 96);
            this.nau_an_button.TabIndex = 3;
            this.nau_an_button.Text = "Nấu ăn";
            this.nau_an_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.nau_an_button.UseVisualStyleBackColor = false;
            this.nau_an_button.Click += new System.EventHandler(this.nau_an_click_box);
            // 
            // don_dep_nha_button
            // 
            this.don_dep_nha_button.BackColor = System.Drawing.Color.Aqua;
            this.don_dep_nha_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("don_dep_nha_button.BackgroundImage")));
            this.don_dep_nha_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.don_dep_nha_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.don_dep_nha_button.ForeColor = System.Drawing.Color.DarkRed;
            this.don_dep_nha_button.Location = new System.Drawing.Point(42, 221);
            this.don_dep_nha_button.Name = "don_dep_nha_button";
            this.don_dep_nha_button.Size = new System.Drawing.Size(113, 96);
            this.don_dep_nha_button.TabIndex = 2;
            this.don_dep_nha_button.Text = "Dọn dẹp nhà";
            this.don_dep_nha_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.don_dep_nha_button.UseVisualStyleBackColor = false;
            this.don_dep_nha_button.Click += new System.EventHandler(this.don_dep_nha_click_box);
            // 
            // giat_ui_button
            // 
            this.giat_ui_button.BackColor = System.Drawing.Color.Aqua;
            this.giat_ui_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("giat_ui_button.BackgroundImage")));
            this.giat_ui_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.giat_ui_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.giat_ui_button.ForeColor = System.Drawing.Color.DarkRed;
            this.giat_ui_button.Location = new System.Drawing.Point(42, 85);
            this.giat_ui_button.Name = "giat_ui_button";
            this.giat_ui_button.Size = new System.Drawing.Size(113, 96);
            this.giat_ui_button.TabIndex = 1;
            this.giat_ui_button.Text = "Giặt ủi";
            this.giat_ui_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.giat_ui_button.UseVisualStyleBackColor = false;
            this.giat_ui_button.Click += new System.EventHandler(this.giat_ui_click_box);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightSalmon;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(102, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "GIÚP VIỆC NHÀ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // home_picturebox
            // 
            this.home_picturebox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("home_picturebox.BackgroundImage")));
            this.home_picturebox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.home_picturebox.Location = new System.Drawing.Point(0, 501);
            this.home_picturebox.Name = "home_picturebox";
            this.home_picturebox.Size = new System.Drawing.Size(62, 56);
            this.home_picturebox.TabIndex = 1;
            this.home_picturebox.TabStop = false;
            this.home_picturebox.Click += new System.EventHandler(this.home_clickbox);
            // 
            // cart_picturebox
            // 
            this.cart_picturebox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cart_picturebox.BackgroundImage")));
            this.cart_picturebox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cart_picturebox.Location = new System.Drawing.Point(58, 501);
            this.cart_picturebox.Name = "cart_picturebox";
            this.cart_picturebox.Size = new System.Drawing.Size(62, 56);
            this.cart_picturebox.TabIndex = 2;
            this.cart_picturebox.TabStop = false;
            this.cart_picturebox.Click += new System.EventHandler(this.card_clickbox);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.PeachPuff;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(74, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "THÔNG TIN GIỎ HÀNG";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.PeachPuff;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Blue;
            this.textBox1.Location = new System.Drawing.Point(38, 85);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 16);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "Giặt ủi:";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.PeachPuff;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Blue;
            this.textBox2.Location = new System.Drawing.Point(38, 129);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 16);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "Nấu ăn:";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.PeachPuff;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Blue;
            this.textBox3.Location = new System.Drawing.Point(38, 173);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 16);
            this.textBox3.TabIndex = 6;
            this.textBox3.Text = "Dọn dẹp:";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.PeachPuff;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Blue;
            this.textBox4.Location = new System.Drawing.Point(38, 219);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 16);
            this.textBox4.TabIndex = 7;
            this.textBox4.Text = "Tổng vệ sinh:";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.PeachPuff;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.Blue;
            this.textBox5.Location = new System.Drawing.Point(38, 264);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(109, 16);
            this.textBox5.TabIndex = 8;
            this.textBox5.Text = "Vệ sinh máy lạnh:";
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.PeachPuff;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.ForeColor = System.Drawing.Color.Blue;
            this.textBox6.Location = new System.Drawing.Point(38, 311);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 16);
            this.textBox6.TabIndex = 9;
            this.textBox6.Text = "Dịch vụ khác:";
            // 
            // giat_ui_text_box
            // 
            this.giat_ui_text_box.BackColor = System.Drawing.Color.PeachPuff;
            this.giat_ui_text_box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.giat_ui_text_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.giat_ui_text_box.ForeColor = System.Drawing.Color.Blue;
            this.giat_ui_text_box.Location = new System.Drawing.Point(216, 85);
            this.giat_ui_text_box.Name = "giat_ui_text_box";
            this.giat_ui_text_box.Size = new System.Drawing.Size(100, 16);
            this.giat_ui_text_box.TabIndex = 10;
            this.giat_ui_text_box.Text = "0";
            this.giat_ui_text_box.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // nau_an_text_box
            // 
            this.nau_an_text_box.BackColor = System.Drawing.Color.PeachPuff;
            this.nau_an_text_box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nau_an_text_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nau_an_text_box.ForeColor = System.Drawing.Color.Blue;
            this.nau_an_text_box.Location = new System.Drawing.Point(216, 129);
            this.nau_an_text_box.Name = "nau_an_text_box";
            this.nau_an_text_box.Size = new System.Drawing.Size(100, 16);
            this.nau_an_text_box.TabIndex = 11;
            this.nau_an_text_box.Text = "0";
            // 
            // don_dep_text_box
            // 
            this.don_dep_text_box.BackColor = System.Drawing.Color.PeachPuff;
            this.don_dep_text_box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.don_dep_text_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.don_dep_text_box.ForeColor = System.Drawing.Color.Blue;
            this.don_dep_text_box.Location = new System.Drawing.Point(216, 173);
            this.don_dep_text_box.Name = "don_dep_text_box";
            this.don_dep_text_box.Size = new System.Drawing.Size(100, 16);
            this.don_dep_text_box.TabIndex = 12;
            this.don_dep_text_box.Text = "0";
            // 
            // tong_ve_sinh_text_box
            // 
            this.tong_ve_sinh_text_box.BackColor = System.Drawing.Color.PeachPuff;
            this.tong_ve_sinh_text_box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tong_ve_sinh_text_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tong_ve_sinh_text_box.ForeColor = System.Drawing.Color.Blue;
            this.tong_ve_sinh_text_box.Location = new System.Drawing.Point(216, 219);
            this.tong_ve_sinh_text_box.Name = "tong_ve_sinh_text_box";
            this.tong_ve_sinh_text_box.Size = new System.Drawing.Size(100, 16);
            this.tong_ve_sinh_text_box.TabIndex = 13;
            this.tong_ve_sinh_text_box.Text = "0";
            // 
            // ve_sinh_may_lanh_text_box
            // 
            this.ve_sinh_may_lanh_text_box.BackColor = System.Drawing.Color.PeachPuff;
            this.ve_sinh_may_lanh_text_box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ve_sinh_may_lanh_text_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ve_sinh_may_lanh_text_box.ForeColor = System.Drawing.Color.Blue;
            this.ve_sinh_may_lanh_text_box.Location = new System.Drawing.Point(216, 264);
            this.ve_sinh_may_lanh_text_box.Name = "ve_sinh_may_lanh_text_box";
            this.ve_sinh_may_lanh_text_box.Size = new System.Drawing.Size(100, 16);
            this.ve_sinh_may_lanh_text_box.TabIndex = 14;
            this.ve_sinh_may_lanh_text_box.Text = "0";
            // 
            // thong_tin_gio_hang_groupbox
            // 
            this.thong_tin_gio_hang_groupbox.BackColor = System.Drawing.Color.PeachPuff;
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.label3);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.thanh_toan_text_box);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.textBox7);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.dich_vu_khac_text_box);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.ve_sinh_may_lanh_text_box);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.tong_ve_sinh_text_box);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.don_dep_text_box);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.nau_an_text_box);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.giat_ui_text_box);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.textBox6);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.textBox5);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.textBox4);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.textBox3);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.textBox2);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.textBox1);
            this.thong_tin_gio_hang_groupbox.Controls.Add(this.label2);
            this.thong_tin_gio_hang_groupbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thong_tin_gio_hang_groupbox.Location = new System.Drawing.Point(0, 0);
            this.thong_tin_gio_hang_groupbox.Name = "thong_tin_gio_hang_groupbox";
            this.thong_tin_gio_hang_groupbox.Size = new System.Drawing.Size(375, 495);
            this.thong_tin_gio_hang_groupbox.TabIndex = 3;
            this.thong_tin_gio_hang_groupbox.TabStop = false;
            // 
            // dich_vu_khac_text_box
            // 
            this.dich_vu_khac_text_box.BackColor = System.Drawing.Color.PeachPuff;
            this.dich_vu_khac_text_box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dich_vu_khac_text_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dich_vu_khac_text_box.ForeColor = System.Drawing.Color.Blue;
            this.dich_vu_khac_text_box.Location = new System.Drawing.Point(216, 311);
            this.dich_vu_khac_text_box.Name = "dich_vu_khac_text_box";
            this.dich_vu_khac_text_box.Size = new System.Drawing.Size(100, 16);
            this.dich_vu_khac_text_box.TabIndex = 15;
            this.dich_vu_khac_text_box.Text = "0";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.PeachPuff;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.ForeColor = System.Drawing.Color.Blue;
            this.textBox7.Location = new System.Drawing.Point(38, 408);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 16);
            this.textBox7.TabIndex = 16;
            this.textBox7.Text = "Thanh toán:";
            // 
            // thanh_toan_text_box
            // 
            this.thanh_toan_text_box.BackColor = System.Drawing.Color.PeachPuff;
            this.thanh_toan_text_box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.thanh_toan_text_box.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thanh_toan_text_box.ForeColor = System.Drawing.Color.Blue;
            this.thanh_toan_text_box.Location = new System.Drawing.Point(216, 408);
            this.thanh_toan_text_box.Name = "thanh_toan_text_box";
            this.thanh_toan_text_box.Size = new System.Drawing.Size(100, 16);
            this.thanh_toan_text_box.TabIndex = 17;
            this.thanh_toan_text_box.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 356);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(283, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "-------------------------------------------------------";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 557);
            this.Controls.Add(this.thong_tin_gio_hang_groupbox);
            this.Controls.Add(this.cart_picturebox);
            this.Controls.Add(this.home_picturebox);
            this.Controls.Add(this.giup_viec_nha_groupbox);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.ShowIcon = false;
            this.Text = "HouseKeeper";
            this.giup_viec_nha_groupbox.ResumeLayout(false);
            this.giup_viec_nha_groupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.home_picturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cart_picturebox)).EndInit();
            this.thong_tin_gio_hang_groupbox.ResumeLayout(false);
            this.thong_tin_gio_hang_groupbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox giup_viec_nha_groupbox;
        private System.Windows.Forms.Label label1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button dich_vu_khac_button;
        private System.Windows.Forms.Button tong_ve_sinh_button;
        private System.Windows.Forms.Button nau_an_button;
        private System.Windows.Forms.Button don_dep_nha_button;
        private System.Windows.Forms.Button giat_ui_button;
        private System.Windows.Forms.PictureBox home_picturebox;
        private System.Windows.Forms.PictureBox cart_picturebox;
        private System.Windows.Forms.Button ve_sinh_may_lanh_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox giat_ui_text_box;
        private System.Windows.Forms.TextBox nau_an_text_box;
        private System.Windows.Forms.TextBox don_dep_text_box;
        private System.Windows.Forms.TextBox tong_ve_sinh_text_box;
        private System.Windows.Forms.TextBox ve_sinh_may_lanh_text_box;
        private System.Windows.Forms.GroupBox thong_tin_gio_hang_groupbox;
        private System.Windows.Forms.TextBox dich_vu_khac_text_box;
        private System.Windows.Forms.TextBox thanh_toan_text_box;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label3;
    }
}