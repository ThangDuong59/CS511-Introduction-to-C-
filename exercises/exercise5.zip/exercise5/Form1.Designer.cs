﻿
namespace Buoi6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grthumuc = new System.Windows.Forms.GroupBox();
            this.grfile = new System.Windows.Forms.GroupBox();
            this.grzip = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btndocfile = new System.Windows.Forms.Button();
            this.txtduongdanfile = new System.Windows.Forms.TextBox();
            this.txttenfile = new System.Windows.Forms.TextBox();
            this.comboBox_ocung = new System.Windows.Forms.ComboBox();
            this.txttenthumuc = new System.Windows.Forms.TextBox();
            this.btnkiemtrathumuc = new System.Windows.Forms.Button();
            this.btntaothumuc = new System.Windows.Forms.Button();
            this.btnxoatatcacacfile = new System.Windows.Forms.Button();
            this.btnxoathumuc = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btnnenfile = new System.Windows.Forms.Button();
            this.btngiainenfile = new System.Windows.Forms.Button();
            this.grthumuc.SuspendLayout();
            this.grfile.SuspendLayout();
            this.grzip.SuspendLayout();
            this.SuspendLayout();
            // 
            // grthumuc
            // 
            this.grthumuc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grthumuc.Controls.Add(this.txttenthumuc);
            this.grthumuc.Controls.Add(this.comboBox_ocung);
            this.grthumuc.Controls.Add(this.btnxoathumuc);
            this.grthumuc.Controls.Add(this.btnxoatatcacacfile);
            this.grthumuc.Controls.Add(this.btntaothumuc);
            this.grthumuc.Controls.Add(this.btnkiemtrathumuc);
            this.grthumuc.Controls.Add(this.label5);
            this.grthumuc.Controls.Add(this.label4);
            this.grthumuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.grthumuc.Location = new System.Drawing.Point(1, 173);
            this.grthumuc.Name = "grthumuc";
            this.grthumuc.Size = new System.Drawing.Size(658, 186);
            this.grthumuc.TabIndex = 0;
            this.grthumuc.TabStop = false;
            this.grthumuc.Text = "THƯ MỤC";
            // 
            // grfile
            // 
            this.grfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.grfile.Controls.Add(this.txttenfile);
            this.grfile.Controls.Add(this.txtduongdanfile);
            this.grfile.Controls.Add(this.btndocfile);
            this.grfile.Controls.Add(this.label3);
            this.grfile.Controls.Add(this.label2);
            this.grfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.grfile.Location = new System.Drawing.Point(1, 3);
            this.grfile.Name = "grfile";
            this.grfile.Size = new System.Drawing.Size(658, 164);
            this.grfile.TabIndex = 0;
            this.grfile.TabStop = false;
            this.grfile.Text = "File";
            // 
            // grzip
            // 
            this.grzip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.grzip.Controls.Add(this.textBox4);
            this.grzip.Controls.Add(this.textBox3);
            this.grzip.Controls.Add(this.textBox2);
            this.grzip.Controls.Add(this.btngiainenfile);
            this.grzip.Controls.Add(this.textBox1);
            this.grzip.Controls.Add(this.btnnenfile);
            this.grzip.Controls.Add(this.label8);
            this.grzip.Controls.Add(this.label7);
            this.grzip.Controls.Add(this.label9);
            this.grzip.Controls.Add(this.label6);
            this.grzip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.grzip.Location = new System.Drawing.Point(1, 365);
            this.grzip.Name = "grzip";
            this.grzip.Size = new System.Drawing.Size(658, 195);
            this.grzip.TabIndex = 0;
            this.grzip.TabStop = false;
            this.grzip.Text = "ZIP";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(665, 32);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(581, 528);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(665, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "THÔNG BÁO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Đường dẫn file";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tên file";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Ổ cứng ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tên thư mục ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "File nén ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Thư mục nén";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(334, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "File nén";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(328, 123);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Thư mục giải nén";
            // 
            // btndocfile
            // 
            this.btndocfile.Location = new System.Drawing.Point(253, 127);
            this.btndocfile.Name = "btndocfile";
            this.btndocfile.Size = new System.Drawing.Size(132, 31);
            this.btndocfile.TabIndex = 1;
            this.btndocfile.Text = "Đọc file";
            this.btndocfile.UseVisualStyleBackColor = true;
            // 
            // txtduongdanfile
            // 
            this.txtduongdanfile.Location = new System.Drawing.Point(209, 37);
            this.txtduongdanfile.Name = "txtduongdanfile";
            this.txtduongdanfile.Size = new System.Drawing.Size(248, 26);
            this.txtduongdanfile.TabIndex = 2;
            // 
            // txttenfile
            // 
            this.txttenfile.Location = new System.Drawing.Point(209, 91);
            this.txttenfile.Name = "txttenfile";
            this.txttenfile.Size = new System.Drawing.Size(248, 26);
            this.txttenfile.TabIndex = 2;
            // 
            // comboBox_ocung
            // 
            this.comboBox_ocung.FormattingEnabled = true;
            this.comboBox_ocung.Location = new System.Drawing.Point(209, 35);
            this.comboBox_ocung.Name = "comboBox_ocung";
            this.comboBox_ocung.Size = new System.Drawing.Size(248, 28);
            this.comboBox_ocung.TabIndex = 1;
            // 
            // txttenthumuc
            // 
            this.txttenthumuc.Location = new System.Drawing.Point(209, 90);
            this.txttenthumuc.Name = "txttenthumuc";
            this.txttenthumuc.Size = new System.Drawing.Size(248, 26);
            this.txttenthumuc.TabIndex = 2;
            // 
            // btnkiemtrathumuc
            // 
            this.btnkiemtrathumuc.Location = new System.Drawing.Point(15, 140);
            this.btnkiemtrathumuc.Name = "btnkiemtrathumuc";
            this.btnkiemtrathumuc.Size = new System.Drawing.Size(154, 31);
            this.btnkiemtrathumuc.TabIndex = 1;
            this.btnkiemtrathumuc.Text = "Kiểm tra thư mục";
            this.btnkiemtrathumuc.UseVisualStyleBackColor = true;
            // 
            // btntaothumuc
            // 
            this.btntaothumuc.Location = new System.Drawing.Point(175, 140);
            this.btntaothumuc.Name = "btntaothumuc";
            this.btntaothumuc.Size = new System.Drawing.Size(150, 31);
            this.btntaothumuc.TabIndex = 1;
            this.btntaothumuc.Text = "Tạo thư mục ";
            this.btntaothumuc.UseVisualStyleBackColor = true;
            // 
            // btnxoatatcacacfile
            // 
            this.btnxoatatcacacfile.Location = new System.Drawing.Point(338, 140);
            this.btnxoatatcacacfile.Name = "btnxoatatcacacfile";
            this.btnxoatatcacacfile.Size = new System.Drawing.Size(159, 31);
            this.btnxoatatcacacfile.TabIndex = 1;
            this.btnxoatatcacacfile.Text = "Xóa tất cả file";
            this.btnxoatatcacacfile.UseVisualStyleBackColor = true;
            // 
            // btnxoathumuc
            // 
            this.btnxoathumuc.Location = new System.Drawing.Point(503, 140);
            this.btnxoathumuc.Name = "btnxoathumuc";
            this.btnxoathumuc.Size = new System.Drawing.Size(149, 31);
            this.btnxoathumuc.TabIndex = 1;
            this.btnxoathumuc.Text = "Xóa thư mục ";
            this.btnxoathumuc.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(118, 41);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(191, 26);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(118, 120);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(191, 26);
            this.textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(461, 41);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(191, 26);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(461, 117);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(191, 26);
            this.textBox4.TabIndex = 2;
            // 
            // btnnenfile
            // 
            this.btnnenfile.Location = new System.Drawing.Point(134, 158);
            this.btnnenfile.Name = "btnnenfile";
            this.btnnenfile.Size = new System.Drawing.Size(150, 31);
            this.btnnenfile.TabIndex = 1;
            this.btnnenfile.Text = "Nén file";
            this.btnnenfile.UseVisualStyleBackColor = true;
            // 
            // btngiainenfile
            // 
            this.btngiainenfile.Location = new System.Drawing.Point(338, 158);
            this.btngiainenfile.Name = "btngiainenfile";
            this.btngiainenfile.Size = new System.Drawing.Size(159, 31);
            this.btngiainenfile.TabIndex = 1;
            this.btngiainenfile.Text = "Giải nén file";
            this.btngiainenfile.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1258, 562);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.grfile);
            this.Controls.Add(this.grzip);
            this.Controls.Add(this.grthumuc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form1";
            this.Text = "File & thư mục";
            this.grthumuc.ResumeLayout(false);
            this.grthumuc.PerformLayout();
            this.grfile.ResumeLayout(false);
            this.grfile.PerformLayout();
            this.grzip.ResumeLayout(false);
            this.grzip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grthumuc;
        private System.Windows.Forms.TextBox txttenthumuc;
        private System.Windows.Forms.ComboBox comboBox_ocung;
        private System.Windows.Forms.Button btnxoathumuc;
        private System.Windows.Forms.Button btnxoatatcacacfile;
        private System.Windows.Forms.Button btntaothumuc;
        private System.Windows.Forms.Button btnkiemtrathumuc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grfile;
        private System.Windows.Forms.TextBox txttenfile;
        private System.Windows.Forms.TextBox txtduongdanfile;
        private System.Windows.Forms.Button btndocfile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grzip;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btngiainenfile;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnnenfile;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label1;
    }
}

