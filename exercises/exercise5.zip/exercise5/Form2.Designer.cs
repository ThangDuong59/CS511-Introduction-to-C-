﻿
namespace Buoi6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.grtest = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button_panelMenu_test = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button_panelMenu_close = new System.Windows.Forms.Button();
            this.grimport = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_panelMenu_import = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelImport = new System.Windows.Forms.Panel();
            this.button_panelImport_key = new System.Windows.Forms.Button();
            this.button_panelImport_question = new System.Windows.Forms.Button();
            this.richTextBox_panelImport_dapAn = new System.Windows.Forms.RichTextBox();
            this.richTextBox_panelImport_questions = new System.Windows.Forms.RichTextBox();
            this.panelTest = new System.Windows.Forms.Panel();
            this.label_panelTest_false = new System.Windows.Forms.Label();
            this.label_panelTest_true = new System.Windows.Forms.Label();
            this.label_panelTest_dapAn = new System.Windows.Forms.Label();
            this.listView_panelTest_dapAn = new System.Windows.Forms.ListView();
            this.button_panelTest_ketQua = new System.Windows.Forms.Button();
            this.button_panelTest_tien = new System.Windows.Forms.Button();
            this.button_panelTest_lui = new System.Windows.Forms.Button();
            this.radioButton_panelTest_b = new System.Windows.Forms.RadioButton();
            this.radioButton_panelTest_d = new System.Windows.Forms.RadioButton();
            this.radioButton_panelTest_c = new System.Windows.Forms.RadioButton();
            this.radioButton_panelTest_a = new System.Windows.Forms.RadioButton();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panelMenu.SuspendLayout();
            this.grtest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.grimport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelImport.SuspendLayout();
            this.panelTest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.MediumBlue;
            this.panelMenu.Controls.Add(this.grtest);
            this.panelMenu.Controls.Add(this.groupBox1);
            this.panelMenu.Controls.Add(this.grimport);
            this.panelMenu.Controls.Add(this.pictureBox1);
            this.panelMenu.Location = new System.Drawing.Point(12, 12);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(275, 630);
            this.panelMenu.TabIndex = 0;
            this.panelMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // grtest
            // 
            this.grtest.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.grtest.Controls.Add(this.pictureBox3);
            this.grtest.Controls.Add(this.button_panelMenu_test);
            this.grtest.Location = new System.Drawing.Point(3, 307);
            this.grtest.Name = "grtest";
            this.grtest.Size = new System.Drawing.Size(269, 85);
            this.grtest.TabIndex = 1;
            this.grtest.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::Buoi6.Properties.Resources.Test;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 86);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // button_panelMenu_test
            // 
            this.button_panelMenu_test.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_panelMenu_test.FlatAppearance.BorderSize = 0;
            this.button_panelMenu_test.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelMenu_test.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_panelMenu_test.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_panelMenu_test.Location = new System.Drawing.Point(102, 0);
            this.button_panelMenu_test.Name = "button_panelMenu_test";
            this.button_panelMenu_test.Size = new System.Drawing.Size(170, 86);
            this.button_panelMenu_test.TabIndex = 0;
            this.button_panelMenu_test.Text = "Test";
            this.button_panelMenu_test.UseVisualStyleBackColor = false;
            this.button_panelMenu_test.Click += new System.EventHandler(this.button_panelMenu_click_test);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.button_panelMenu_close);
            this.groupBox1.Location = new System.Drawing.Point(3, 542);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(270, 80);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox4.BackgroundImage = global::Buoi6.Properties.Resources.Close;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 79);
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // button_panelMenu_close
            // 
            this.button_panelMenu_close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button_panelMenu_close.FlatAppearance.BorderSize = 0;
            this.button_panelMenu_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelMenu_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_panelMenu_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_panelMenu_close.Location = new System.Drawing.Point(102, 0);
            this.button_panelMenu_close.Name = "button_panelMenu_close";
            this.button_panelMenu_close.Size = new System.Drawing.Size(168, 79);
            this.button_panelMenu_close.TabIndex = 0;
            this.button_panelMenu_close.Text = "Close";
            this.button_panelMenu_close.UseVisualStyleBackColor = false;
            this.button_panelMenu_close.Click += new System.EventHandler(this.button_panelMenu_click_close);
            // 
            // grimport
            // 
            this.grimport.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.grimport.Controls.Add(this.pictureBox2);
            this.grimport.Controls.Add(this.button_panelMenu_import);
            this.grimport.Location = new System.Drawing.Point(3, 204);
            this.grimport.Name = "grimport";
            this.grimport.Size = new System.Drawing.Size(269, 80);
            this.grimport.TabIndex = 1;
            this.grimport.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::Buoi6.Properties.Resources.Import;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 79);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // button_panelMenu_import
            // 
            this.button_panelMenu_import.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button_panelMenu_import.FlatAppearance.BorderSize = 0;
            this.button_panelMenu_import.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelMenu_import.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_panelMenu_import.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_panelMenu_import.Location = new System.Drawing.Point(102, 0);
            this.button_panelMenu_import.Name = "button_panelMenu_import";
            this.button_panelMenu_import.Size = new System.Drawing.Size(167, 79);
            this.button_panelMenu_import.TabIndex = 0;
            this.button_panelMenu_import.Text = "Import";
            this.button_panelMenu_import.UseVisualStyleBackColor = false;
            this.button_panelMenu_import.Click += new System.EventHandler(this.button_panelMenu_click_import);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Buoi6.Properties.Resources.Exam;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(88, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(102, 106);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelImport
            // 
            this.panelImport.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelImport.Controls.Add(this.button_panelImport_key);
            this.panelImport.Controls.Add(this.button_panelImport_question);
            this.panelImport.Controls.Add(this.richTextBox_panelImport_dapAn);
            this.panelImport.Controls.Add(this.richTextBox_panelImport_questions);
            this.panelImport.Location = new System.Drawing.Point(293, 12);
            this.panelImport.Name = "panelImport";
            this.panelImport.Size = new System.Drawing.Size(771, 630);
            this.panelImport.TabIndex = 1;
            // 
            // button_panelImport_key
            // 
            this.button_panelImport_key.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_panelImport_key.BackgroundImage = global::Buoi6.Properties.Resources.ImportKey;
            this.button_panelImport_key.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_panelImport_key.FlatAppearance.BorderSize = 0;
            this.button_panelImport_key.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelImport_key.Location = new System.Drawing.Point(12, 510);
            this.button_panelImport_key.Name = "button_panelImport_key";
            this.button_panelImport_key.Size = new System.Drawing.Size(114, 112);
            this.button_panelImport_key.TabIndex = 2;
            this.button_panelImport_key.UseVisualStyleBackColor = false;
            this.button_panelImport_key.Click += new System.EventHandler(this.button_panelImport_click_key);
            // 
            // button_panelImport_question
            // 
            this.button_panelImport_question.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_panelImport_question.BackgroundImage = global::Buoi6.Properties.Resources.ImportQuestion;
            this.button_panelImport_question.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_panelImport_question.FlatAppearance.BorderSize = 0;
            this.button_panelImport_question.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelImport_question.Location = new System.Drawing.Point(12, 59);
            this.button_panelImport_question.Name = "button_panelImport_question";
            this.button_panelImport_question.Size = new System.Drawing.Size(114, 112);
            this.button_panelImport_question.TabIndex = 2;
            this.button_panelImport_question.UseVisualStyleBackColor = false;
            this.button_panelImport_question.Click += new System.EventHandler(this.button_panelImport_click_question);
            // 
            // richTextBox_panelImport_dapAn
            // 
            this.richTextBox_panelImport_dapAn.Location = new System.Drawing.Point(144, 388);
            this.richTextBox_panelImport_dapAn.Name = "richTextBox_panelImport_dapAn";
            this.richTextBox_panelImport_dapAn.Size = new System.Drawing.Size(624, 233);
            this.richTextBox_panelImport_dapAn.TabIndex = 1;
            this.richTextBox_panelImport_dapAn.Text = "";
            // 
            // richTextBox_panelImport_questions
            // 
            this.richTextBox_panelImport_questions.Location = new System.Drawing.Point(144, 3);
            this.richTextBox_panelImport_questions.Name = "richTextBox_panelImport_questions";
            this.richTextBox_panelImport_questions.Size = new System.Drawing.Size(624, 379);
            this.richTextBox_panelImport_questions.TabIndex = 0;
            this.richTextBox_panelImport_questions.Text = "";
            // 
            // panelTest
            // 
            this.panelTest.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelTest.Controls.Add(this.label_panelTest_false);
            this.panelTest.Controls.Add(this.label_panelTest_true);
            this.panelTest.Controls.Add(this.label_panelTest_dapAn);
            this.panelTest.Controls.Add(this.listView_panelTest_dapAn);
            this.panelTest.Controls.Add(this.button_panelTest_ketQua);
            this.panelTest.Controls.Add(this.button_panelTest_tien);
            this.panelTest.Controls.Add(this.button_panelTest_lui);
            this.panelTest.Controls.Add(this.radioButton_panelTest_b);
            this.panelTest.Controls.Add(this.radioButton_panelTest_d);
            this.panelTest.Controls.Add(this.radioButton_panelTest_c);
            this.panelTest.Controls.Add(this.radioButton_panelTest_a);
            this.panelTest.Controls.Add(this.pictureBox5);
            this.panelTest.Location = new System.Drawing.Point(1081, 12);
            this.panelTest.Name = "panelTest";
            this.panelTest.Size = new System.Drawing.Size(771, 630);
            this.panelTest.TabIndex = 2;
            this.panelTest.Visible = false;
            this.panelTest.Paint += new System.Windows.Forms.PaintEventHandler(this.pnltest_Paint);
            // 
            // label_panelTest_false
            // 
            this.label_panelTest_false.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_panelTest_false.ForeColor = System.Drawing.Color.Crimson;
            this.label_panelTest_false.Location = new System.Drawing.Point(154, 580);
            this.label_panelTest_false.Name = "label_panelTest_false";
            this.label_panelTest_false.Size = new System.Drawing.Size(100, 23);
            this.label_panelTest_false.TabIndex = 8;
            this.label_panelTest_false.Text = "False: 0";
            // 
            // label_panelTest_true
            // 
            this.label_panelTest_true.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_panelTest_true.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label_panelTest_true.Location = new System.Drawing.Point(20, 580);
            this.label_panelTest_true.Name = "label_panelTest_true";
            this.label_panelTest_true.Size = new System.Drawing.Size(100, 23);
            this.label_panelTest_true.TabIndex = 7;
            this.label_panelTest_true.Text = "True: 0";
            // 
            // label_panelTest_dapAn
            // 
            this.label_panelTest_dapAn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_panelTest_dapAn.ForeColor = System.Drawing.Color.Blue;
            this.label_panelTest_dapAn.Location = new System.Drawing.Point(170, 12);
            this.label_panelTest_dapAn.Name = "label_panelTest_dapAn";
            this.label_panelTest_dapAn.Size = new System.Drawing.Size(586, 106);
            this.label_panelTest_dapAn.TabIndex = 6;
            // 
            // listView_panelTest_dapAn
            // 
            this.listView_panelTest_dapAn.HideSelection = false;
            this.listView_panelTest_dapAn.Location = new System.Drawing.Point(13, 396);
            this.listView_panelTest_dapAn.Name = "listView_panelTest_dapAn";
            this.listView_panelTest_dapAn.Size = new System.Drawing.Size(743, 153);
            this.listView_panelTest_dapAn.TabIndex = 5;
            this.listView_panelTest_dapAn.UseCompatibleStateImageBehavior = false;
            this.listView_panelTest_dapAn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView_panelTest_mouseClick_dapAn);
            // 
            // button_panelTest_ketQua
            // 
            this.button_panelTest_ketQua.BackColor = System.Drawing.Color.DarkBlue;
            this.button_panelTest_ketQua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button_panelTest_ketQua.FlatAppearance.BorderSize = 0;
            this.button_panelTest_ketQua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelTest_ketQua.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_panelTest_ketQua.ForeColor = System.Drawing.Color.White;
            this.button_panelTest_ketQua.Image = ((System.Drawing.Image)(resources.GetObject("button_panelTest_ketQua.Image")));
            this.button_panelTest_ketQua.Location = new System.Drawing.Point(307, 317);
            this.button_panelTest_ketQua.Name = "button_panelTest_ketQua";
            this.button_panelTest_ketQua.Size = new System.Drawing.Size(198, 73);
            this.button_panelTest_ketQua.TabIndex = 4;
            this.button_panelTest_ketQua.Text = "Result board";
            this.button_panelTest_ketQua.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button_panelTest_ketQua.UseVisualStyleBackColor = false;
            this.button_panelTest_ketQua.Click += new System.EventHandler(this.button_panelTest_click_ketQua);
            // 
            // button_panelTest_tien
            // 
            this.button_panelTest_tien.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_panelTest_tien.BackgroundImage = global::Buoi6.Properties.Resources.Next;
            this.button_panelTest_tien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_panelTest_tien.FlatAppearance.BorderSize = 0;
            this.button_panelTest_tien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelTest_tien.Location = new System.Drawing.Point(623, 290);
            this.button_panelTest_tien.Name = "button_panelTest_tien";
            this.button_panelTest_tien.Size = new System.Drawing.Size(133, 82);
            this.button_panelTest_tien.TabIndex = 3;
            this.button_panelTest_tien.UseVisualStyleBackColor = false;
            this.button_panelTest_tien.Click += new System.EventHandler(this.button_panelTest_click_tien);
            // 
            // button_panelTest_lui
            // 
            this.button_panelTest_lui.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_panelTest_lui.BackgroundImage = global::Buoi6.Properties.Resources.Back;
            this.button_panelTest_lui.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_panelTest_lui.FlatAppearance.BorderSize = 0;
            this.button_panelTest_lui.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_panelTest_lui.Location = new System.Drawing.Point(43, 280);
            this.button_panelTest_lui.Name = "button_panelTest_lui";
            this.button_panelTest_lui.Size = new System.Drawing.Size(125, 102);
            this.button_panelTest_lui.TabIndex = 3;
            this.button_panelTest_lui.UseVisualStyleBackColor = false;
            this.button_panelTest_lui.Click += new System.EventHandler(this.button_panelTest_click_lui);
            // 
            // radioButton_panelTest_b
            // 
            this.radioButton_panelTest_b.AutoSize = true;
            this.radioButton_panelTest_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_panelTest_b.Location = new System.Drawing.Point(56, 229);
            this.radioButton_panelTest_b.Name = "radioButton_panelTest_b";
            this.radioButton_panelTest_b.Size = new System.Drawing.Size(152, 29);
            this.radioButton_panelTest_b.TabIndex = 2;
            this.radioButton_panelTest_b.Text = "radioButton3";
            this.radioButton_panelTest_b.UseVisualStyleBackColor = true;
            // 
            // radioButton_panelTest_d
            // 
            this.radioButton_panelTest_d.AutoSize = true;
            this.radioButton_panelTest_d.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.radioButton_panelTest_d.Location = new System.Drawing.Point(465, 229);
            this.radioButton_panelTest_d.Name = "radioButton_panelTest_d";
            this.radioButton_panelTest_d.Size = new System.Drawing.Size(152, 29);
            this.radioButton_panelTest_d.TabIndex = 2;
            this.radioButton_panelTest_d.Text = "radioButton4";
            this.radioButton_panelTest_d.UseVisualStyleBackColor = true;
            // 
            // radioButton_panelTest_c
            // 
            this.radioButton_panelTest_c.AutoSize = true;
            this.radioButton_panelTest_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.radioButton_panelTest_c.Location = new System.Drawing.Point(465, 142);
            this.radioButton_panelTest_c.Name = "radioButton_panelTest_c";
            this.radioButton_panelTest_c.Size = new System.Drawing.Size(152, 29);
            this.radioButton_panelTest_c.TabIndex = 2;
            this.radioButton_panelTest_c.Text = "radioButton2";
            this.radioButton_panelTest_c.UseVisualStyleBackColor = true;
            // 
            // radioButton_panelTest_a
            // 
            this.radioButton_panelTest_a.AutoSize = true;
            this.radioButton_panelTest_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.radioButton_panelTest_a.Location = new System.Drawing.Point(56, 142);
            this.radioButton_panelTest_a.Name = "radioButton_panelTest_a";
            this.radioButton_panelTest_a.Size = new System.Drawing.Size(152, 29);
            this.radioButton_panelTest_a.TabIndex = 2;
            this.radioButton_panelTest_a.Text = "radioButton1";
            this.radioButton_panelTest_a.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::Buoi6.Properties.Resources.Question;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(25, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(113, 95);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "True.png");
            this.imageList1.Images.SetKeyName(1, "False.png");
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1077, 654);
            this.ControlBox = false;
            this.Controls.Add(this.panelTest);
            this.Controls.Add(this.panelImport);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panelMenu.ResumeLayout(false);
            this.grtest.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.grimport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelImport.ResumeLayout(false);
            this.panelTest.ResumeLayout(false);
            this.panelTest.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox grtest;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button_panelMenu_test;
        private System.Windows.Forms.GroupBox grimport;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button_panelMenu_import;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button_panelMenu_close;
        private System.Windows.Forms.Panel panelImport;
        private System.Windows.Forms.Button button_panelImport_key;
        private System.Windows.Forms.Button button_panelImport_question;
        private System.Windows.Forms.RichTextBox richTextBox_panelImport_dapAn;
        private System.Windows.Forms.RichTextBox richTextBox_panelImport_questions;
        private System.Windows.Forms.Panel panelTest;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.RadioButton radioButton_panelTest_b;
        private System.Windows.Forms.RadioButton radioButton_panelTest_d;
        private System.Windows.Forms.RadioButton radioButton_panelTest_c;
        private System.Windows.Forms.RadioButton radioButton_panelTest_a;
        private System.Windows.Forms.Button button_panelTest_tien;
        private System.Windows.Forms.Button button_panelTest_lui;
        private System.Windows.Forms.ListView listView_panelTest_dapAn;
        private System.Windows.Forms.Button button_panelTest_ketQua;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label_panelTest_dapAn;
        private System.Windows.Forms.Label label_panelTest_false;
        private System.Windows.Forms.Label label_panelTest_true;
    }
}